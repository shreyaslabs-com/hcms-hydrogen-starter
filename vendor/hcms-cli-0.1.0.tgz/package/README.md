# @hcms/cli — `hcms`

Developer CLI for HydrogenCMS storefronts: build custom sections in your repo, check them, and make
them available in the theme editor.

Run it inside the storefront (the starter has it as a dev dependency: `pnpm exec hcms …`).

| Command                                       | What it does                                                                                                                                                                                                             |
| --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `hcms validate [--json]`                      | Loads `app/sections/index.ts` and checks every section/block schema. Exit 1 on problems (use in CI).                                                                                                                     |
| `hcms push [--dry-run]`                       | Validates, builds the manifest (`registry.manifest()`, same as `/__hcms/manifest`) and uploads it. The editor and publish use it right away.                                                                             |
| `hcms dev [--port N] [--offline]`             | Runs the storefront's `dev` script (Vite + Hydrogen). On every save under `app/` it re-validates and, with a token, pushes a **dev** manifest: the editor lists the sections you're building. Ctrl-C removes them again. |
| `hcms init <type> [--name "Title"] [--force]` | Writes `app/sections/custom/<type>.tsx` from a minimal valid template (the starter registers every file in that folder).                                                                                                 |

Common options: `--root <dir>`, `--entry <file>` (default `app/sections/index.ts`), `--shop`,
`--admin-url`.

## Setup

1. In HydrogenCMS › **Settings › Developer tokens**, create a token (publishers and admins). It is
   shown once.
2. Put the three values in your shell or the storefront's `.env` (never commit it):

   ```sh
   HCMS_DEV_TOKEN=hcms_dt_…
   HCMS_SHOP=acme.myshopify.com        # or PUBLIC_STORE_DOMAIN
   HCMS_ADMIN_URL=https://…            # or HCMS_API_URL (already set on the starter)
   ```

3. `hcms validate`, then `hcms push` after you deploy (or `hcms dev` while building).

## The registry module

`app/sections/index.ts` must export `sectionDefinitions` (array), optionally `blockDefinitions`
and `registry` (`createRegistry(...)`); in the starter it also picks up every file in
`app/sections/custom/` (`app/sections/custom.ts`). It is loaded with the storefront's own Vite (≥ 6.1,
`runnerImport`), so TypeScript/TSX and `~/` imports work and validation uses the storefront's
`@hcms/hydrogen` version.

## How push and dev differ

- `push` replaces the store's section manifest (what the deployed storefront renders). Sections
  that aren't deployed yet show a placeholder in the editor and render nothing live; the next
  storefront sync ("Sync sections" or the daily job) overwrites it with the deployed manifest.
- `dev` writes a separate overlay that only the editor reads (expires after 8 hours without a
  push). Publish never uses it, so work in progress can't reach the live store.

Tokens can only update section manifests for their store; the Admin API token is never involved.
